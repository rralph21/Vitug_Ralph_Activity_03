"""This module defines the Payment class."""

__author__ = ""
__version__ = ""

from billing_account.billing_account import BillingAccount
from payee.payee import Payee
