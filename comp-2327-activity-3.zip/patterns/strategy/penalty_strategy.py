"""This module defines the PenaltyStrategy class."""

__author__ = ""
__version__ = ""
