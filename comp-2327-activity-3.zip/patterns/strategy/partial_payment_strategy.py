"""This module defines the PartialPaymentStrategy class."""

__author__ = ""
__version__ = ""
