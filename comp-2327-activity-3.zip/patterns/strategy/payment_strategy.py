"""This module defines the PaymentStrategy class."""

__author__ = ""
__version__ = ""
